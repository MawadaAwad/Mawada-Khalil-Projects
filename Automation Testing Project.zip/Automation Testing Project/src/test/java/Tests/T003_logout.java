package Tests;

import com.github.javafaker.Faker;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pages.P003_logout;

import static org.openqa.selenium.By.xpath;

public class T003_logout extends testBase{
    Faker fake = new Faker();
    P003_logout logout;
    SoftAssert soft = new SoftAssert();

    // Test Case 4
@Test(priority = 1)
    public void testCase4_Logout(){

     logout = new P003_logout(driver);
     soft = new SoftAssert();
    test = report.createTest("Logout");

    String saveName = "Mawada";
    String saveMail = "oertuisepoyuwpty@irtioertuioesoo.com";
    String savePassword ="mawada123" ;

    soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
    logout.goLogin();
    soft.assertEquals(driver.findElement(By.xpath("//*[@class=\"login-form\"]/h2")).getText(),"Login to your account","The label is not found");
    logout.LoginWithCorrectMail(saveMail);
    logout.LoginWithCorrectPassword(savePassword);
    logout.clickLogin();
    soft.assertEquals(driver.findElement(By.cssSelector("ul[class=\"nav navbar-nav\"] li:nth-child(10) a")).getText(), "Logged in as "+saveName+"", "The label is not found");
    logout.clickLogout();
    soft.assertEquals(driver.findElement(By.xpath("//*[@class=\"login-form\"]/h2")).getText(),"Login to your account","The label is not found");
    soft.assertAll();



}
}
