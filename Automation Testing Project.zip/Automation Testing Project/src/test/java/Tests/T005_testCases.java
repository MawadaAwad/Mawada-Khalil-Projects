package Tests;

import com.github.javafaker.Faker;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pages.P004_ContactUs;
import pages.P005_testCases;

import java.time.Duration;

import static org.openqa.selenium.By.xpath;

public class T005_testCases extends testBase{
    Faker fake = new Faker();
    P005_testCases cases;
    SoftAssert soft ;


// Test Case 7
    @Test(priority = 1)
    public void testCase7_navigateToTestCasesPage(){
        cases = new P005_testCases(driver);
        soft = new SoftAssert();
        test = report.createTest("Navigate to the test cases page");

        soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
        cases.clickTestCases();
        soft.assertTrue(driver.findElement(xpath("//*[@id=\"form\"]//*[@class=\"container\"]")).isDisplayed());
        soft.assertAll();




    }



}

// Test Case 7
