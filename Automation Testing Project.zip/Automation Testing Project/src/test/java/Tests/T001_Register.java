package Tests;

import com.github.javafaker.Faker;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pages.P001_Register;

import static org.openqa.selenium.By.xpath;

public class T001_Register extends testBase {
    P001_Register register;
    Faker fake = new Faker();
    SoftAssert soft ;




    //set Values.
    String fakeName = fake.name().name();
    String fakeEmail = fake.internet().safeEmailAddress();
    public String saveName = "Mawada";
    public String saveMail = "oertuisepoyuwpty@iraaj.com";
    public String savePassword = "mawada123";
    String fakePassword = fake.internet().password(10,15);
    String fakeFirstName = fake.name().firstName();
    String fakeLastName = fake.name().firstName();
    String fakeCompany = fake.company().name();
    String fakeAddress1 = fake.address().fullAddress();
    String fakeAddress2 = fake.address().secondaryAddress();
    String fakeState = fake.address().state();
    String fakeCity = fake.address().city();
    String fakeZipCode = fake.address().zipCode();
    String fakeMobileNumber = fake.phoneNumber().phoneNumber();

    // Test Case 1
    @Test(priority = 1)
    public void testCase1_register() {
        register= new P001_Register(driver);
        soft = new SoftAssert();
        test = report.createTest("Register");

        soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
        register.goSignUp();
        soft.assertEquals(driver.findElement(xpath("//*[@class=\"signup-form\"]/h2")).getText(), "New User Signup!", "The label is not found");
        register.sendSignUpName(saveName);
        register.sendSignUpEmail(saveMail);
        register.clickSignUp();
        soft.assertEquals(driver.findElement(xpath("//*[@class=\"login-form\"]/*[@style=\"color: #FE980F;\"]/b")).getText(), "ENTER ACCOUNT INFORMATION", "The label is not found");
        register.selectGenderOptions();
        register.sendPassword(savePassword);
        register.selectRandomDate();
        register.selectNewsLetter();
        register.selectOption();
        register.sendFirstName(fakeFirstName);
        register.sendLastName(fakeLastName);
        register.sendCompany(fakeCompany);
        register.sendAddress1(fakeAddress1);
        register.sendAddress2(fakeAddress2);
        register.selectCountry();
        register.sendState(fakeState);
        register.sendCity(fakeCity);
        register.sendZipCode(fakeZipCode);
        register.sendMobileNumber(fakeMobileNumber);
        register.clickCreateAccount();
        register.clickContinue();
        soft.assertEquals(driver.findElement(By.cssSelector("ul[class=\"nav navbar-nav\"] li:nth-child(10) a")).getText(), "Logged in as "+saveName+"", "The label is not found");
        soft.assertAll();


    }
// to perform the next test case kindly make the lines 53,54 comments to prevent delete the registered account
    @Test(priority = 2)
// Test Case 5
    public void registerWithIncorrectEmail() {

        register = new P001_Register(driver);
        soft = new SoftAssert();
        test = report.createTest("Register with incorrect credential");


        soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
        register.goSignUp();
        soft.assertEquals(driver.findElement(xpath("//*[@class=\"signup-form\"]/h2")).getText(), "New User Signup!", "The label is not found");
        register.sendSignUpName(saveName);
        register.sendSignUpEmail(saveMail);
        register.clickSignUp();
        soft.assertEquals(driver.findElement(By.xpath("//*[@class=\"signup-form\"]/*[@method=\"POST\"]/p")).getText(),"Email Address already exist!","The label is not found");
        soft.assertAll();


    }


}
