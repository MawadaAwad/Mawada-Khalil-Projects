package Tests;

import com.github.javafaker.Faker;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pages.P007_Subscription;

import static org.openqa.selenium.By.xpath;

public class T007_Subiscription extends testBase{

    Faker fake = new Faker();
    P007_Subscription subscription ;
    SoftAssert soft ;


   // Test Case 10
    @Test(priority = 1)
  public void testCase10_subscriptionHomePage(){
        subscription = new P007_Subscription(driver);
        soft = new SoftAssert();
        test = report.createTest("Subscription from home page");

        String fakeEmail = fake.internet().safeEmailAddress();
        soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
        subscription.scrollDown();
        subscription.getSubscriptionText();
        subscription.sendSubscribeEmail(fakeEmail);
        subscription.clickSubscribeSubmit();
        soft.assertEquals(driver.findElement(By.xpath( "//*[@id=\"success-subscribe\"]/div")).getText(),"You have been successfully subscribed!");
        soft.assertAll();


    }



    // Test Case 11
    @Test
    public void testCase11_subscriptionCartPage() {
        subscription = new P007_Subscription(driver);
        soft = new SoftAssert();
        test = report.createTest("Subscription from cart page");

        String fakeEmail = fake.internet().safeEmailAddress();

        soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
        subscription.clickCart();
        subscription.scrollDown();
        subscription.getSubscriptionText();
        subscription.sendSubscribeEmail(fakeEmail);
        subscription.clickSubscribeSubmit();
        soft.assertEquals(driver.findElement(By.xpath( "//*[@id=\"success-subscribe\"]/div")).getText(),"You have been successfully subscribed!");
        soft.assertAll();

        soft.assertAll();

    }






    }
