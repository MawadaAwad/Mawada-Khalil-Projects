package Tests;

import com.github.javafaker.Faker;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pages.P005_testCases;
import pages.P006_Products;

import static org.openqa.selenium.By.xpath;

public class T006_Products extends testBase{

    Faker fake = new Faker();
    P006_Products product ;
    SoftAssert soft ;
   String searchName = "T-shirt";

    // Test Case 8
    @Test(priority = 1)
    public void verifyAllProductsAndProductDetailPage(){
        product = new P006_Products(driver);
        soft = new SoftAssert();
        test = report.createTest("Verify product details");



        soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
        product.goToProductsList();
        soft.assertEquals(driver.getCurrentUrl(),"https://automationexercise.com/products");
        soft.assertEquals(driver.findElement(By.xpath("//*[@class=\"title text-center\"]")).getText(),"ALL PRODUCTS");
        soft.assertTrue(driver.findElement(xpath("//*[@class=\"features_items\"]")).isDisplayed());
        product.goToViewFirstProduct();
        soft.assertEquals(driver.getCurrentUrl(),"https://automationexercise.com/product_details/1");
        soft.assertTrue(driver.findElement(product.productName).isDisplayed());
        soft.assertTrue(driver.findElement(product.productCategory).isDisplayed());
        soft.assertTrue(driver.findElement(product.productPrice).isDisplayed());
        soft.assertTrue(driver.findElement(product.productAvailability).isDisplayed());
        soft.assertTrue(driver.findElement(product.productConditions).isDisplayed());
        soft.assertTrue(driver.findElement(product.productBrands).isDisplayed());
        soft.assertAll();
    }

    // Test Case 9

    @Test(priority = 2)
    public void searchProduct() {
    product = new P006_Products(driver);
    soft = new SoftAssert();
        test = report.createTest(" Search on product product");

    soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
    product.goToProductsList();
    soft.assertEquals(driver.getCurrentUrl(), "https://automationexercise.com/products");
    soft.assertEquals(driver.findElement(By.xpath("//*[@class=\"title text-center\"]")).getText(), "ALL PRODUCTS");
    product.sendSearchProduct(searchName);
    product.submitSearch();
    soft.assertEquals(driver.findElement(By.xpath("//*[@class=\"title text-center\"]")).getText(), "SEARCHED PRODUCTS");
    product.getSearchedNameText();
    product.verifyProductsRelatedToSearchedName();
    soft.assertTrue(product.verifyProductsRelatedToSearchedName().contains(product.verifyProductsRelatedToSearchedName()));
    soft.assertAll();

}





}
