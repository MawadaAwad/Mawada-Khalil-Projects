package Tests;

import com.github.javafaker.Faker;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pages.P004_ContactUs;

import static org.openqa.selenium.By.xpath;

public class T004_ContactUs extends testBase{
    Faker fake = new Faker();
    P004_ContactUs contact;
    SoftAssert soft ;


    String fakeName = fake.name().name();
    String fakeEmail = fake.internet().safeEmailAddress();
    String fakeSubject = fake.name().title();
    String fakeMessage = fake.name().nameWithMiddle()+""+ fake.address() + fake.commerce() ;
    String filePath = "C:\\Users\\NIC\\Pictures\\pexels.jpg";

    // Test Case 6
   @Test(priority = 1)
    public void testCase6_contactUs(){
       contact = new P004_ContactUs(driver);
       soft = new SoftAssert();
       test = report.createTest("Contact Us");

       soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
       contact.clickContactUs();
       soft.assertEquals(driver.findElement(By.xpath("//*[@class=\"contact-form\"]/h2")).getText(),"GET IN TOUCH","The text is not found");
       contact.sendContactName(fakeName);
       contact.sendContactMail(fakeEmail);
       contact.sendContactSubject(fakeSubject);
       contact.sendContactMessage(fakeMessage);
       contact.sendUploadFile(filePath);
       contact.clickSubmit();
       contact.clickAlert();
       soft.assertEquals(driver.findElement(By.xpath("//*[@class=\"status alert alert-success\"]")).getText(),"Success! Your details have been submitted successfully.","The text is not found");
       contact.clickLandedToHome();
       soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
       soft.assertAll();



    }











}
