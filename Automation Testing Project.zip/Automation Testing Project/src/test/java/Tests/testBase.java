package Tests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.github.javafaker.Faker;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class testBase {
    WebDriver driver ;
    Faker fake = new Faker() ;
    public static ExtentReports report;
    public static ExtentTest test;



    @BeforeSuite
    public void setupSuite(){
        report = new ExtentReports();
        ExtentSparkReporter spark = new ExtentSparkReporter("report/report.html");
        report.attachReporter(spark);
    }
    //    @BeforeMethod
    @BeforeMethod
    public void setUpthrows(){

            WebDriverManager.edgedriver().setup();
            EdgeOptions options = new EdgeOptions();
            options.addExtensions(new File("E:\\Intllej\\Automation Testing Project\\src\\main\\resources\\GIGHMMPIOBKLFEPJOCNAMGKKBIGLIDOM_5_21_0_0.crx"));
            driver = new EdgeDriver(options);
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
            wait.until(ExpectedConditions.numberOfWindowsToBe(2));
            ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
            driver.switchTo().window(tabs.get(1));
            driver.close();
            driver.switchTo().window(tabs.get(0));
            driver.get("https://automationexercise.com/");
        }



        @AfterMethod
        public  void quitBrowser(@NotNull ITestResult result) {



            switch (result.getStatus()) {
                case ITestResult.FAILURE:
                    test.fail(result.getThrowable());
                    break;
                case ITestResult.SUCCESS:
                    test.pass("Test Passed Successfully");
                    break;
                case ITestResult.SKIP:
                    test.skip(result.getThrowable());
                    break;
                default:
                    break;
            }
        driver.quit();
    }




    @AfterSuite
    public void tearDown() throws IOException {
        report.flush();
        Desktop.getDesktop().open(new File("report/report.html"));
    }

}