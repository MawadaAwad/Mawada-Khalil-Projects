package Tests;

import com.github.javafaker.Faker;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pages.P001_Register;
import pages.P002_Login;

import static org.openqa.selenium.By.xpath;

public class T002_Login extends testBase {

    Faker fake = new Faker();
    P002_Login login;
    SoftAssert soft ;
     T001_Register reg = new T001_Register();

    // set Values
    String fakeEmail = fake.internet().safeEmailAddress();
    String fakePassword = fake.internet().password(1,8);
    String saveName =reg.saveName ;
    String saveMail = reg.saveMail;
    String savePassword = reg.savePassword;
// Test Case 2
    @Test(priority = 1)
    public void testCase2_loginUserWithCorrectEmailAndPassword(){
         //String saveMail = "oertuiepoyuwpty@irtioertuioe.com";
        // String savePassword ="mawada123" ;
        login = new P002_Login(driver);
        soft = new SoftAssert();
        test = report.createTest("Login with correct credential");

        soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
        login.goLogin();
        soft.assertEquals(driver.findElement(By.xpath("//*[@class=\"login-form\"]/h2")).getText(),"Login to your account","The label is not found");
        login.LoginWithCorrectMail(saveMail);
        login.LoginWithCorrectPassword(savePassword);
        login.clickLogin();
        soft.assertEquals(driver.findElement(By.cssSelector("ul[class=\"nav navbar-nav\"] li:nth-child(10) a")).getText(), "Logged in as "+saveName+"", "The label is not found");
        login.clickDeleteAccount();
        soft.assertEquals(driver.findElement(xpath("//*[@class=\"title text-center\"]/b")).getText(), "ACCOUNT DELETED!", "The label is not found");
        login.clickContinue();
        soft.assertAll();


    }
// Test Case 3
  @Test(priority = 2)
    public void testCase3_loginUserWithIncorrectEmailAndPassword(){
      test = report.createTest("Login with incorrect credential");

      login = new P002_Login(driver);
      soft = new SoftAssert();
      soft.assertTrue(driver.findElement(xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]")).isDisplayed());
      login.goLogin();
      soft.assertEquals(driver.findElement(By.xpath("//*[@class=\"login-form\"]/h2")).getText(),"Login to your account","The label is not found");
      login.LoginWithCorrectMail(fakeEmail);
      login.LoginWithCorrectPassword(fakePassword);
      login.clickLogin();
      soft.assertEquals(driver.findElement(By.xpath("//*[@action=\"/login\"]/p")).getText(),"Your email or password is incorrect!","The label is not found");       soft.assertAll();
      soft.assertAll();

  }








}
