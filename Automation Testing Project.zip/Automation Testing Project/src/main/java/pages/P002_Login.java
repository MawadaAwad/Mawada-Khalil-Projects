package pages;

import com.github.javafaker.Faker;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P002_Login extends base{

    public P002_Login(WebDriver driver) {super(driver);}
    WebDriver driver;
    Faker fake = new Faker();
    // Values Identification ;

    protected final By signUp = By.xpath("//*[@href=\"/login\"]");
    protected final By loginEmail = By.xpath("//*[@data-qa=\"login-email\"]");
    protected final By  loginPassword = By.xpath("//*[@data-qa=\"login-password\"]");
    protected final By loginButton = By.xpath("//*[@data-qa=\"login-button\"]");
    protected final By  deleteAccount = By.xpath("//*[@href=\"/delete_account\"]");
    protected final By  Continue = By.xpath("//*[@data-qa=\"continue-button\"]");

    // Methods
    public void goLogin(){click(signUp);}
    public void LoginWithCorrectMail(String txt) {
        sendkeys(loginEmail, txt);
    }
    public void LoginWithCorrectPassword(String txt){
        sendkeys(loginPassword,txt);
    }
    public void clickLogin(){ click(loginButton);}
    public void clickDeleteAccount(){ click(deleteAccount);}
    public void clickContinue(){ click(Continue);}








}










