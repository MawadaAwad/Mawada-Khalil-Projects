package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import com.github.javafaker.Faker;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class base {

    protected WebDriver driver;
    Faker fake = new Faker();
    SoftAssert soft = new SoftAssert();
    WebDriverWait wait;

    public base(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(this.driver, Duration.ofSeconds(10));
    }

    public void click(By by) {
        wait.until(ExpectedConditions.elementToBeClickable(by));
        wait.until(ExpectedConditions.presenceOfElementLocated(by));

        driver.findElement(by).click();
    }

    public void checkBox(By by) {
        wait.until(ExpectedConditions.elementToBeClickable(by));
        wait.until(ExpectedConditions.presenceOfElementLocated(by));
        driver.findElement(by).click();
        wait.until(ExpectedConditions.elementToBeSelected(by));

    }


    public void click(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
    }

    public void checkBox(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
        wait.until(ExpectedConditions.visibilityOf(element));
        wait.until(ExpectedConditions.elementToBeSelected(element));
        element.click();
    }

    public void Quit(By by) {
        wait.until(ExpectedConditions.presenceOfElementLocated(by));
        driver.quit();
    }


    public void sendkeys(By by, String txt) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
        wait.until(ExpectedConditions.presenceOfElementLocated(by));
        wait.until(ExpectedConditions.visibilityOfElementLocated(by));
        driver.findElement(by).clear();
        driver.findElement(by).sendKeys(txt);
    }

    public void sendkeys(WebElement element, String txt) {

        wait.until(ExpectedConditions.visibilityOf(element));
        wait.until(ExpectedConditions.elementSelectionStateToBe(element, true));
        element.clear();
        element.sendKeys(txt);
    }


    public void selectRandomOptions(WebElement element, By optionNumber, int min) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(optionNumber));
        wait.until(ExpectedConditions.presenceOfElementLocated(optionNumber));
        Select item = new Select(element);
        int optionSize = driver.findElements(optionNumber).size();
        int random = fake.number().numberBetween(min, optionSize + 1);
        item.selectByIndex(random);

    }

    public void selectRandomCountry(WebElement element, By optionNumber, int min) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(optionNumber));
        wait.until(ExpectedConditions.presenceOfElementLocated(optionNumber));
        Select item = new Select(element);
        int optionSize = driver.findElements(optionNumber).size();
        int random = fake.number().numberBetween(min, optionSize + 1);
        item.selectByIndex(random);

    }

    public void alert() {
        Alert ok = driver.switchTo().alert();
        ok.accept();
    }

    public String getText(WebElement element, String txt) {
        wait.until(ExpectedConditions.visibilityOf(element));
        wait.until(ExpectedConditions.elementSelectionStateToBe(element, true));

        return element.getText();

    }


    public String getText(By by, String txt) {
        wait.until(ExpectedConditions.elementSelectionStateToBe(by, true));
        return driver.findElement(by).getText();

    }
}