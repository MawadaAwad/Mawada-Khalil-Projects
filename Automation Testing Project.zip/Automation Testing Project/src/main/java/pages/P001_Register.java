package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeSelected;

public class P001_Register extends base{
    public P001_Register(WebDriver driver) {
        super(driver);
    }
  // Values Identification ;

    public final By homeSlidShow = By.xpath("//*[@id=\"slider-carousel\"]/*[@class=\"carousel-inner\"]");

    protected final By signUp = By.xpath("//*[@href=\"/login\"]");

    protected final By  signUpName = By.xpath("//*[@data-qa=\"signup-name\"]");

    protected final By signUpEmail = By.xpath("//*[@data-qa=\"signup-email\"]");

    protected final By signUpButton = By.xpath("//*[@data-qa=\"signup-button\"]");

    protected final By password = By.id("password");

    @FindBy(id = "days")
    protected WebElement selectDay;
    final By selectDayOptions = By.xpath("//*[@data-qa=\"days\"]/option");

    @FindBy(id = "months")
    protected WebElement selectMonth;
    final By selectMonthOptions = By.xpath("//*[@data-qa=\"months\"]/option");

    @FindBy(id = "years")
    protected WebElement selectYear;
    final By selectYearOptions = By.xpath("//*[@data-qa=\"years\"]/option");

    protected final By letter = By.id("newsletter");

    protected final By option = By.id("optin");

    protected final By  firstName = By.id("first_name");

    protected final By  LastName = By.id("last_name");

    protected final By  company = By.id("company");

    protected final By  address1 = By.id("address1");

    protected final By  address2 = By.id("address2");


    @FindBy(id = "country")
    WebElement country;
    protected final By  countryOption = By.xpath("//*[@id=\"country\"]/option");

    protected final By  state = By.id("state");

    protected final By  city = By.id("city");

    protected final By  zipCode = By.id("zipcode");

    protected final By  mobileNumber = By.id("mobile_number");

    protected final By  createAccount = By.xpath("//*[@data-qa=\"create-account\"]");

    protected final By  Continue = By.xpath("//*[@data-qa=\"continue-button\"]");

    protected final By  deleteAccount = By.xpath("//*[@href=\"/delete_account\"]");

    protected final By  Continue2 = By.xpath("//*[@data-qa=\"continue-button\"]");

    @FindBy(xpath = "//*[@class=\"features_items\"]//*[@class=\"col-sm-4\"][1]//*[@class=\"productinfo text-center\"]/p")
    WebElement homeProductPrice;

    @FindBy(xpath = "//*[@class=\"features_items\"]//*[@class=\"col-sm-4\"][1]//*[@class=\"productinfo text-center\"]/h2")
    WebElement homeProductTitle;

    @FindBy(xpath = "//*[@src=\"/get_product_picture/1\"]")
    WebElement homeProductImg;

    @FindBy(xpath = "//*[@class=\"product-information\"]/span/span")
    WebElement infoProductPrice;

    @FindBy(xpath = "//*[@class=\"product-information\"]/h2")
    WebElement infoProductTitle;

    @FindBy(xpath = "//*[@src=\"/get_product_picture/1\"]")
    WebElement infoProductImg;

    protected final By productList = By.xpath("//*[@href=\"/products\"]");

    protected final By randomProduct = By.xpath("//*[@href=\"/product_details/1\"]");


    // Methods

    public void goSignUp(){click(signUp);}

    public void sendSignUpName(String txt){
        sendkeys(signUpName,txt);
    }

    public void sendSignUpEmail(String txt){
        sendkeys(signUpEmail,txt);
    }


    public void clickSignUp(){ click(signUpButton);}

    int GenderOptions = driver.findElements(By.xpath("//*[@class=\"radio-inline\"]")).size();
    public void selectGenderOptions(){
        int random = fake.number().numberBetween(1,GenderOptions+1);
        final By Gender = By.xpath("//*[@class=\"radio-inline\"]["+random+"]/label/div/span/input");
        click(Gender);}

    public void sendPassword(String txt){
        sendkeys(password,txt);
    }

    public void selectRandomDate() {
        selectRandomOptions(selectDay,selectDayOptions,2);
        selectRandomOptions(selectMonth,selectMonthOptions,2);
        selectRandomOptions(selectYear,selectYearOptions,2);}

    public void selectNewsLetter(){
        checkBox(letter);}

    public void selectOption(){
        checkBox(option);}

    public void sendFirstName(String txt){
        sendkeys(firstName,txt);
    }

    public void sendLastName(String txt){sendkeys(LastName,txt);}

    public void sendCompany( String txt){sendkeys(company,txt);}

    public void sendAddress1(String txt){sendkeys(address1,txt);}

    public void sendAddress2(String txt){sendkeys(address2,txt);}

    public void selectCountry() {selectRandomOptions(country,countryOption,1);}

    public void sendState(String txt){sendkeys(state,txt);}

    public void sendCity(String txt){sendkeys(city,txt);}

    public void sendZipCode(String txt){sendkeys(zipCode,txt);}

    public void sendMobileNumber(String txt){sendkeys(mobileNumber,txt);}

    public void clickCreateAccount(){ click(createAccount);}

    public void clickContinue(){ click(Continue);}

    public void clickDeleteAccount(){ click(deleteAccount);}

    public void clickContinue2(){ click(Continue2);}

//    public String getHomeProductTitle(){
//        String homeTitle =homeProductPrice.getText();
//        return homeTitle;
//    }
//    public String getHomeProductPrice(){
//        String homePrice =homeProductTitle.getText();
//        return homePrice;
//    }
//    public String getHomeProductImg(){
//        String infoImg =homeProductImg.getAttribute("src");
//        return infoImg;
//    }
//
//
//    public void clickProductPage(){ click(productList);}
//
//    public void ViewRandomProduct(){ click(randomProduct);}
//
//
//    public String getInfoProductTitle(){
//        String infoTitle =infoProductTitle.getText();
//    return infoTitle;
//    }
//    public String getInfoProductPrice(){
//        String infoPrice =infoProductPrice.getText();
//        return infoPrice;
//    }
//    public String getInfoProductImg(){
//        String infoImg =infoProductImg.getAttribute("src");
//        return infoImg;
//
//    }


}

