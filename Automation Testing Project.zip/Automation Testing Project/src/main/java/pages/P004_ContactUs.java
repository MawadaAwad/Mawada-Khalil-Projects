package pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class P004_ContactUs extends base{
    public P004_ContactUs(WebDriver driver) {
        super(driver);
    }

    ///// Values Identification
    protected final By contactUs = By.xpath("//*[@class=\"nav navbar-nav\"]/li[8]/a");
    protected final By contactName = By.xpath("//*[@data-qa=\"name\"]");
    protected final By contactMail = By.xpath("//*[@data-qa=\"email\"]");
    protected final By contactSubject = By.xpath("//*[@data-qa=\"subject\"]");
    protected final By contactMessage = By.xpath("//*[@data-qa=\"message\"]");
    protected final By uploadFile = By.xpath("//*[@name=\"upload_file\"]");
    protected final By submit = By.xpath("//*[@data-qa=\"submit-button\"]");
    protected final By landedToHome = By.xpath("//*[@class=\"fa fa-angle-double-left\"]");


    ///// Methods
    public void clickContactUs(){click(contactUs);}
    public void sendContactName(String txt){
        sendkeys(contactName,txt);
    }
    public void sendContactMail(String txt){
        sendkeys(contactMail,txt);
    }
    public void sendContactSubject(String txt){
        sendkeys(contactSubject,txt);
    }
    public void sendContactMessage(String txt){
        sendkeys(contactMessage,txt);
    }
    public void sendUploadFile(String txt){sendkeys(uploadFile,txt);}
    public void clickSubmit(){click(submit);}
    public void clickAlert(){Alert ok = driver.switchTo().alert();ok.accept();}
    public void clickLandedToHome(){click(landedToHome);}


}
