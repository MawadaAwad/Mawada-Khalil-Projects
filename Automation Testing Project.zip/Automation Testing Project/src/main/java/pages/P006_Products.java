package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class P006_Products extends base {
    public P006_Products(WebDriver driver) {
        super(driver);
    }

    ///// Values Identification

    protected final By goProductsList = By.xpath("//*[@class=\"material-icons card_travel\"]");
    protected final By viewFirstProduct = By.xpath("//*[@href=\"/product_details/1\"]");
    public final By productName = By.xpath("//*[@class=\"product-information\"]/h2");
    public final By productCategory = By.xpath("//*[@class=\"product-information\"]/p[1]");
    public final By productPrice = By.xpath("//*[@class=\"product-information\"]/span/span");
    public final By productAvailability = By.xpath("//*[@class=\"product-information\"]/p[2]/b");
    public final By productConditions = By.xpath("//*[@class=\"product-information\"]/p[3]/b");
    public final By productBrands = By.xpath("//*[@class=\"product-information\"]/p[4]/b");
    protected final By searchField = By.id("search_product");
    protected final By Submit = By.id("submit_search");
    @FindBy(id = "search_product")
    WebElement searchedName;
//    @FindBy(id = "search_product")
//    WebElement searchedName;
//    protected final By searchedName = By.id("search_product");

    /// Methods
    public void goToProductsList() {
        click(goProductsList);
    }

    public void goToViewFirstProduct() {
        click(viewFirstProduct);
    }

    public void sendSearchProduct(String txt) {
        driver.findElement(searchField).sendKeys(txt);
    }

    public void submitSearch() {
        click(Submit);
    }

    public String getSearchedNameText() {
        String getName = searchedName.getText();
        return getName;
    }

    public String verifyProductsRelatedToSearchedName() {

        String relateProductName = null;
        int SubCategory = driver.findElements(By.xpath("//*[@class=\"col-sm-9 padding-right\"]//*[@class=\"col-sm-4\"]")).size();
        for (int i = 1; i <= SubCategory; i++) {
           By productsName = By.xpath("//*[@class=\"features_items\"]//*[@class=\"col-sm-4\"][" + i + "]//*[@class=\"productinfo text-center\"]/p");
            relateProductName = driver.findElement(productsName).getText();
            return relateProductName;
        }
        return relateProductName;
    }


}





