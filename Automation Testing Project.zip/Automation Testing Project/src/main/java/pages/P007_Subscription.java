package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class P007_Subscription extends base{
    public P007_Subscription(WebDriver driver) {
        super(driver);
    }
    ///// Values Identification

    protected final By subscriptionText = By.xpath( "//*[@class=\"single-widget\"]/h2");
    protected final By subscribeEmail = By.id("susbscribe_email");
    protected final By subscribeSubmit = By.id("subscribe");
    protected final By cart = By.xpath("//*[@href=\"/view_cart\"]");


    ///// Methods

    public void scrollDown(){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
    }

    public String getSubscriptionText(){
        String getText = driver.findElement(subscriptionText).getText();
        return getText;
    }
    public void sendSubscribeEmail(String txt){
        driver.findElement(subscribeEmail).sendKeys(txt);
    }
    public void clickSubscribeSubmit(){
        click(subscribeSubmit);
    }
    public void clickCart(){
        click(cart);
    }

}


