package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P003_logout extends P002_Login {
    public P003_logout(WebDriver driver) {
        super(driver);
    }
    By logoutButton = By.xpath("//*[@href=\"/logout\"]");
   public void clickLogout(){ click(logoutButton);}

}
