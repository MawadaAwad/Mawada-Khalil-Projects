package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P005_testCases extends base{
    public P005_testCases(WebDriver driver) {
        super(driver);
    }

    ///// Values Identification

    protected final By testCases = By.xpath("//*[@href=\"/test_cases\"]");
    protected final By testCasesList = By.xpath("//*[@id=\"form\"]//*[@class=\"container\"]");

    ///// Methods
    public void clickTestCases(){click(testCases);}

}
